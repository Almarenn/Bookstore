package bgu.spl.mics.application;

import bgu.spl.mics.application.passiveObjects.Customer;
import com.google.gson.JsonObject;

public class Services {
    public JsonObject time;
    public int selling;
    public int inventoryService;
    public int logistics;
    public int resourcesService;
    public Customer[] customers;
}
