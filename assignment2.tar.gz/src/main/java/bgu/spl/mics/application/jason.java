package bgu.spl.mics.application;

import bgu.spl.mics.application.passiveObjects.BookInventoryInfo;

public class jason {
    public BookInventoryInfo[] initialInventory;
    public Resources[] initialResources;
    public Services services;


}
